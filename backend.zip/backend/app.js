// app.js
require('dotenv').config();

const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const mongoose = require('mongoose');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Load the database connection utility
const connectDB = require('./utils/db');

// Load API routes
const locationRoutes = require('./routes/location')(io); // Pass the socket.io instance to the routes

// Middleware
app.use(express.json());

// Connect to MongoDB
connectDB();

// Use API routes
app.use('/api', locationRoutes);

// Export the server instance for testing or other use
module.exports = server;
