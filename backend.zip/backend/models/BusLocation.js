// models/BusLocation.js

const mongoose = require('mongoose');

const busLocationSchema = new mongoose.Schema({
    bus_id: {
        type: String,
        required: true,
        unique: true
    },
    latitude: {
        type: Number,
        required: true
    },
    longitude: {
        type: Number,
        required: true
    },
    timestamp: {
        type: Date,
        default: Date.now
    }
});

const BusLocation = mongoose.model('BusLocation', busLocationSchema);

module.exports = BusLocation;