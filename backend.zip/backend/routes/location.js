// routes/location.js

const express = require('express');
const BusLocation = require('../models/BusLocation');

module.exports = (io) => {
    const router = express.Router();

    router.post('/location', async (req, res) => {
        const { bus_id, latitude, longitude } = req.body;

        // Input validation
        if (!bus_id || !latitude || !longitude) {
            return res.status(400).json({ message: 'Missing bus_id, latitude, or longitude' });
        }

        try {
            // Find and update the bus location. `findOneAndUpdate` is efficient.
            const updatedBus = await BusLocation.findOneAndUpdate(
                { bus_id: bus_id },
                { latitude, longitude, timestamp: Date.now() },
                { new: true, upsert: true } // `new: true` returns the updated document, `upsert: true` creates a new one if it doesn't exist
            );

            // Log the update for debugging
            console.log(`Updated location for bus ${updatedBus.bus_id}: (${updatedBus.latitude}, ${updatedBus.longitude})`);

            // Emit the real-time data to all connected clients
            io.emit('bus_location_update', {
                bus_id: updatedBus.bus_id,
                latitude: updatedBus.latitude,
                longitude: updatedBus.longitude
            });

            res.status(200).json({ message: 'Location updated successfully', data: updatedBus });
        } catch (error) {
            console.error('Error updating location:', error);
            res.status(500).json({ message: 'Server error' });
        }
    });

    return router;
};